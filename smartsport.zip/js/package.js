{
  "scripts": {
    "prebuild": "node ./scripts/fetch-data.js",
    "build": "echo 'static build'"
  },
  "type": "module"
}
